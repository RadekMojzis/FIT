﻿#cd D:\GitHub\IPP

echo " * * IPP DKA TEST * * *"
echo ""


function my_test ($num, $prm) {

	echo "* Test $num"
	(& "php" ".\main.php" $prm) 2> .\tests\out\test$num.err
	$output = $LastExitCode
	echo -n $output > .\tests\out\test$num.!!!
	if (!$output) {
		echo "    OK"
	}

	$object1 = cat .\tests\ref-out\test$num.!!!
	$object2 = cat .\tests\out\test$num.!!!
	if ($object1 -eq $null)  { $object1 = "" }
	if ($object2 -eq $null)  { $object2 = "" }
	diff $object1 $object2

	$object1 = cat .\tests\ref-out\test$num.err
	$object2 = cat .\tests\out\test$num.err
	if ($object1 -eq $null) { $object1 = "" }
	if ($object2 -eq $null) { $object2 = "" }
	diff $object1 $object2

	$object1 = cat .\tests\ref-out\test$num.out
	$object2 = cat .\tests\out\test$num.out
	if ($object1 -eq $null) { $object1 = "" }
	if ($object2 -eq $null) { $object2 = "" }
	diff $object1 $object2

    echo ""
}

my_test "01"  "--input=.\tests\test01.in", "--output=.\tests\out\test01.out", "-d"
my_test "02"  "--input=.\tests\test02.in", "--output=.\tests\out\test02.out", "-d"
my_test "03"  "--input=.\tests\test03.in", "--output=.\tests\out\test03.out", "-d"
my_test "04"  "--input=.\tests\test04.in", "--output=.\tests\out\test04.out"
my_test "05"  "--input=.\tests\test05.in", "--output=.\tests\out\test05.out"
my_test "06"  "--input=.\tests\test06.in", "--output=.\tests\out\test06.out", "-d"
my_test "07"  "--input=.\tests\test07.in", "--output=.\tests\out\test07.out", "-e"
my_test "08"  "--input=.\tests\test08.in", "--output=.\tests\out\test08.out", "-d", "--no-epsilon-rules"
my_test "09"  "--input=.\tests\test09.in", "--output=.\tests\out\test09.out"
my_test "10"  "--input=.\tests\test10.in", "--output=.\tests\out\test10.out"
my_test "90"  "--input=.\tests\test90.in", "--output=.\tests\out\test90.out", "--rules-only"
my_test "91"  "--input=.\tests\test91.in", "--output=.\tests\out\test91.out", "--white-char"
my_test "92"  "--input=.\tests\test92.in", "--output=.\tests\out\test92.out", "-w", "-r"

pause