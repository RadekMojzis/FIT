var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwzÃ",
  1: "bgmptv",
  2: "bcfglmpstuv",
  3: "acdfgilmnoprstvz",
  4: "abcdeghilmnoprstv",
  5: "abfgimopuv",
  6: "afiu",
  7: "abflnrstu",
  8: "aceimpvw",
  9: "Ã",
  10: "it"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

