var searchData=
[
  ['near',['NEAR',['../student__pipeline_8h.html#ae9e1c8a3d097c4fa8df79abc03911ec5a428074548efef09696dcc7eaff3d195b',1,'student_pipeline.h']]],
  ['noperspective',['NOPERSPECTIVE',['../program_8h.html#a8472f01c511d77bbfb981a46618ea1eaacdc92eb62e3be278780c22beb101971c',1,'program.h']]]
];
