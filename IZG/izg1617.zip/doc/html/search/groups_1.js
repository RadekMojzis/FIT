var searchData=
[
  ['Úkoly_20v_20gpu_20části',['Úkoly v gpu části',['../group__gpu__side.html',1,'']]]
];
