#!/usr/bin/env python3

def count(n):
    while n > 0:
        n -= 1

count(10**8)
count(10**8)

