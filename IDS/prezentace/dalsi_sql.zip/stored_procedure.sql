DROP USER zendulk1;

CREATE OR REPLACE PROCEDURE create_user (login IN VARCHAR2)AUTHID CURRENT_USER
IS
  user_login VARCHAR2(128);
  user_passwd VARCHAR2(4000);
BEGIN
  user_login:=UPPER(login);
--user_passwd:=passwd;
  IF (user_passwd IS NULL) THEN
    user_passwd:=lower(login);
  END IF; 
-- vytvoreni uzivatele
  EXECUTE IMMEDIATE 'CREATE USER "'||user_login||'" PROFILE "DEFAULT" IDENTIFIED BY "'||user_passwd||'" 
  DEFAULT TABLESPACE "USERS"
  QUOTA 10 M ON USERS
  ACCOUNT UNLOCK';
  -- prirazeni role uzivateli  
  EXECUTE IMMEDIATE 'GRANT "STUDENTROLE" TO "'||user_login||'"';
 END;
/
show errors;

EXECUTE create_user ('zendulk1');

