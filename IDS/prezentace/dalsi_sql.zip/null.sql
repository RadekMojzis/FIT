-- Aritmetick� operace
SELECT 100 + NULL
FROM DUAL;
-- Logick� operace
SELECT CASE WHEN NULL>100 THEN 'ano' WHEN NULL<=100 THEN 'ne'ELSE  'nezn�mo'END ano_ne
FROM DUAL;
-- Klienti z Brna a mimobrn�n�t�
SELECT *
FROM Klient;

SELECT *
FROM Klient
WHERE mesto='Brno' OR mesto<>'Brno';
-- Vo�en� pr�zdn� adresy
INSERT INTO Klient (r_cislo, jmeno)
VALUES ('562817/2318', 'Josef Trnka');
-- Test chyb�j�c� hodnoty
SELECT *
FROM Klient
WHERE mesto=NULL;
SELECT *
FROM Klient
WHERE mesto<>NULL;
SELECT *
FROM Klient
WHERE mesto IS NULL;

-- Agrega�n� funkce
SELECT COUNT(NULL), SUM(NULL), AVG(NULL), MAX(NULL)
FROM DUAL;

SELECT COUNT(c_uctu) pocet_uctu, SUM (stav) stav, COUNT(*) pocet_radku
FROM Klient NATURAL LEFT JOIN Ucet;

SELECT COUNT(c_uctu) pocet_uctu, SUM (stav) stav, COUNT(*) pocet_radku
FROM Klient NATURAL JOIN Ucet;

SELECT r_cislo, jmeno, COUNT(c_uctu) pocet_uctu, SUM (stav) stav
FROM Klient NATURAL LEFT JOIN Ucet
GROUP BY r_cislo,jmeno
ORDER BY pocet_uctu DESC;

SELECT r_cislo, jmeno, COUNT(c_uctu) pocet_uctu, COALESCE(SUM (stav),0) stav
FROM Klient NATURAL LEFT JOIN Ucet
GROUP BY r_cislo,jmeno
ORDER BY pocet_uctu DESC;

SELECT COUNT(NULL), SUM(NULL), AVG(NULL), MAX(NULL)
FROM DUAL;

-- Obnova
ROLLBACK;
